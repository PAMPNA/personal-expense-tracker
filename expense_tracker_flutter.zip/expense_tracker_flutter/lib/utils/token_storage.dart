import 'package:shared_preferences/shared_preferences.dart';
import 'package:jwt_decoder/jwt_decoder.dart';

class TokenStorage {
  static const _tokenKey = 'jwt_token';

  // ================= SAVE TOKEN =================
  static Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_tokenKey, token);
  }

  // ================= GET TOKEN =================
  static Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  // ================= GET USERNAME FROM JWT =================
  static Future<String?> getUsername() async {
    final token = await getToken();

    if (token == null) {
      print('❌ No token found');
      return null;
    }

    final decoded = JwtDecoder.decode(token);
    print('🔍 DECODED TOKEN: $decoded');

    return decoded['name']; // make sure backend sends "name"
  }

  // ================= CLEAR TOKEN (LOGOUT) =================
  static Future<void> clearToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
  }
}

