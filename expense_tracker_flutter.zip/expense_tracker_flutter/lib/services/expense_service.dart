import 'dart:convert';
import 'package:http/http.dart' as http;
import '../utils/api_constants.dart';
import '../utils/token_storage.dart';
import '../models/expense.dart';

class ExpenseService {
  // ================= GET EXPENSES =================
  static Future<List<Expense>> getExpenses() async {
    final token = await TokenStorage.getToken();

    final response = await http.get(
      Uri.parse(ApiConstants.expenses),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to load expenses');
    }

    final List data = jsonDecode(response.body);
    return data.map((e) => Expense.fromJson(e)).toList();
  }

  // ================= ADD EXPENSE =================
  static Future<void> addExpense(
      String title,
      double amount,
      String category,
      String date,
      ) async {
    final token = await TokenStorage.getToken();

    final response = await http.post(
      Uri.parse(ApiConstants.expenses),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'title': title,
        'amount': amount,
        'category': category,
        'date': date,
      }),
    );

    if (response.statusCode != 201 && response.statusCode != 200) {
      throw Exception('Failed to add expense');
    }
  }

  // ================= DELETE EXPENSE =================
  static Future<void> deleteExpense(String id) async {
    final token = await TokenStorage.getToken();

    final response = await http.delete(
      Uri.parse('${ApiConstants.expenses}/$id'),
      headers: {
        'Authorization': 'Bearer $token',
      },
    );

    if (response.statusCode != 204 && response.statusCode != 200) {
      throw Exception('Failed to delete expense');
    }
  }

  // ================= UPDATE EXPENSE (✅ FIXED) =================
  static Future<void> updateExpense(
      String id,
      String title,
      double amount,
      String category,
      String date,
      ) async {
    final token = await TokenStorage.getToken();

    final response = await http.put(
      Uri.parse('${ApiConstants.expenses}/$id'),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $token',
      },
      body: jsonEncode({
        'title': title,
        'amount': amount,
        'category': category,
        'date': date,
      }),
    );

    if (response.statusCode != 200) {
      throw Exception('Failed to update expense');
    }
  }
}
