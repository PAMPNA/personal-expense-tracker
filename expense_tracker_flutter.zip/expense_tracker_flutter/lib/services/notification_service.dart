import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notifications =
  FlutterLocalNotificationsPlugin();

  // 🔹 INIT
  static Future<void> init() async {
    const androidInit =
    AndroidInitializationSettings('@mipmap/ic_launcher');

    const settings = InitializationSettings(android: androidInit);

    await _notifications.initialize(settings);
  }

  // 🔔 SHOW TEST NOTIFICATION (IMMEDIATE)
  static Future<void> showTestNotification() async {
    await _notifications.show(
      100, // notification id
      'Quick Check-In 💙',
      'Did you note today’s spending yet?',
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'test_channel',
          'Test Notifications',
          channelDescription: 'Test expense reminders',
          importance: Importance.high,
          priority: Priority.high,
        ),
      ),
    );
  }

  // 🔕 CANCEL TEST NOTIFICATION
  static Future<void> cancelTestNotification() async {
    await _notifications.cancel(999);
  }
}
