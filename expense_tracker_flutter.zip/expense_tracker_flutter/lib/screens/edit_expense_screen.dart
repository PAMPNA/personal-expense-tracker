import 'package:flutter/material.dart';
import '../models/expense.dart';
import '../services/expense_service.dart';

class EditExpenseScreen extends StatefulWidget {
  final Expense expense;

  const EditExpenseScreen({super.key, required this.expense});

  @override
  State<EditExpenseScreen> createState() => _EditExpenseScreenState();
}

class _EditExpenseScreenState extends State<EditExpenseScreen> {
  late TextEditingController titleCtrl;
  late TextEditingController amountCtrl;
  late TextEditingController categoryCtrl;
  late TextEditingController dateCtrl;

  @override
  void initState() {
    super.initState();
    titleCtrl = TextEditingController(text: widget.expense.title);
    amountCtrl =
        TextEditingController(text: widget.expense.amount.toString());
    categoryCtrl = TextEditingController(text: widget.expense.category);
    dateCtrl = TextEditingController(
      text: widget.expense.date.toIso8601String().split('T')[0],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Expense')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: titleCtrl,
              decoration: const InputDecoration(labelText: 'Title'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: amountCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Amount'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: categoryCtrl,
              decoration: const InputDecoration(labelText: 'Category'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: dateCtrl,
              decoration: const InputDecoration(labelText: 'Date (YYYY-MM-DD)'),
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  await ExpenseService.updateExpense(
                    widget.expense.id,
                    titleCtrl.text,
                    double.parse(amountCtrl.text),
                    categoryCtrl.text,
                    dateCtrl.text,
                  );

                  Navigator.pop(context, true);
                },
                child: const Text('Update Expense'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
