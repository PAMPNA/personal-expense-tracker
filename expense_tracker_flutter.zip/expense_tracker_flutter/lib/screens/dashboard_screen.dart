import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/expense.dart';
import '../services/expense_service.dart';
import '../utils/token_storage.dart';
import '../services/notification_service.dart';
import 'add_expense_screen.dart';
import 'edit_expense_screen.dart';
import '../widgets/category_bar_chart.dart';
import 'login_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<List<Expense>> _expensesFuture;
  String username = '';

  // Filters
  DateTime? selectedDate;
  String? selectedCategory;

  // Notification toggle
  bool notificationEnabled = false;

  @override
  void initState() {
    super.initState();
    _expensesFuture = ExpenseService.getExpenses();
    loadUsername();
  }

  Future<void> loadUsername() async {
    final name = await TokenStorage.getUsername();
    if (mounted) {
      setState(() => username = name ?? 'User');
    }
  }

  /* ================= FILTER FUNCTION ================= */
  List<Expense> applyFilters(List<Expense> expenses) {
    return expenses.where((e) {
      final dateMatch = selectedDate == null ||
          (e.date.year == selectedDate!.year &&
              e.date.month == selectedDate!.month &&
              e.date.day == selectedDate!.day);

      final categoryMatch = selectedCategory == null ||
          e.category.toLowerCase() ==
              selectedCategory!.toLowerCase();

      return dateMatch && categoryMatch;
    }).toList();
  }

  /* ================= CATEGORY HELPERS ================= */
  IconData getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return Icons.fastfood;
      case 'travel':
        return Icons.directions_car;
      case 'shopping':
        return Icons.shopping_bag;
      case 'groceries':
        return Icons.shopping_cart;
      case 'entertainment':
        return Icons.movie;
      case 'recharge':
        return Icons.phone_android;
      case 'emi':
        return Icons.credit_card;
      default:
        return Icons.account_balance_wallet;
    }
  }

  Color getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'food':
        return Colors.orange;
      case 'travel':
        return Colors.blue;
      case 'shopping':
        return Colors.purple;
      case 'groceries':
        return Colors.green;
      case 'entertainment':
        return Colors.red;
      case 'recharge':
        return Colors.teal;
      case 'emi':
        return Colors.grey;
      default:
        return Colors.blueGrey;
    }
  }

  /* ================= KPI HELPERS ================= */
  double todayTotal(List<Expense> e) {
    final now = DateTime.now();
    return e
        .where((x) =>
    x.date.year == now.year &&
        x.date.month == now.month &&
        x.date.day == now.day)
        .fold(0, (a, b) => a + b.amount);
  }

  double monthTotal(List<Expense> e) {
    final now = DateTime.now();
    return e
        .where((x) =>
    x.date.year == now.year &&
        x.date.month == now.month)
        .fold(0, (a, b) => a + b.amount);
  }

  double overallTotal(List<Expense> e) =>
      e.fold(0, (a, b) => a + b.amount);

  Widget kpiCard(String title, double value, Color color) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 6),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 10,
            )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 6),
            Text(
              '₹${value.toStringAsFixed(0)}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /* ================= UI ================= */
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6FA),

      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Row(
          children: const [
            CircleAvatar(
              backgroundColor: Colors.white,
              child: Icon(Icons.account_balance_wallet, color: Colors.blue),
            ),
            SizedBox(width: 10),
            Text('Expense Tracker'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async {
              final confirm = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Logout'),
                  content: const Text('Are you sure you want to logout?'),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context, false),
                      child: const Text('Cancel'),
                    ),
                    TextButton(
                      onPressed: () => Navigator.pop(context, true),
                      child: const Text('Logout'),
                    ),
                  ],
                ),
              );

              if (confirm == true) {
                await TokenStorage.clearToken();

                if (!mounted) return;
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                      (route) => false,
                );
              }
            },
          ),
        ],
      ),

      /* ================= + MENU ================= */
      floatingActionButton: PopupMenuButton<int>(
        icon: const Icon(Icons.add_circle, size: 48, color: Colors.blue),
        itemBuilder: (context) => const [
          PopupMenuItem(value: 1, child: Text('➕ Add Expense')),
          PopupMenuItem(value: 2, child: Text('📅 Filter by Date')),
          PopupMenuItem(value: 3, child: Text('🏷 Filter by Category')),
          PopupMenuItem(value: 4, child: Text('♻ Reset Filters')),
        ],
        onSelected: (value) async {
          if (value == 1) {
            await Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AddExpenseScreen()),
            );
            setState(() {
              _expensesFuture = ExpenseService.getExpenses();
            });
          }

          if (value == 2) {
            final picked = await showDatePicker(
              context: context,
              initialDate: DateTime.now(),
              firstDate: DateTime(2020),
              lastDate: DateTime(2100),
            );
            if (picked != null) {
              setState(() => selectedDate = picked);
            }
          }

          if (value == 3) {
            final category = await showDialog<String>(
              context: context,
              builder: (_) => SimpleDialog(
                title: const Text('Select Category'),
                children: [
                  'Food',
                  'Travel',
                  'Shopping',
                  'Groceries',
                  'Entertainment',
                  'Recharge',
                  'EMI',
                ]
                    .map(
                      (c) => SimpleDialogOption(
                    child: Text(c),
                    onPressed: () => Navigator.pop(context, c),
                  ),
                )
                    .toList(),
              ),
            );

            if (category != null) {
              setState(() => selectedCategory = category);
            }
          }

          if (value == 4) {
            setState(() {
              selectedDate = null;
              selectedCategory = null;
            });
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('Filters cleared')),
            );
          }
        },
      ),

      body: FutureBuilder<List<Expense>>(
        future: _expensesFuture,
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final expenses = applyFilters(snapshot.data!);

          return Column(
            children: [
              const SizedBox(height: 12),

              // 👋 Greeting
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'Hi, $username 👋',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ),

              // 🔔 Notification Toggle
              Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: SwitchListTile(
                    title: const Text(
                      'Test Notification',
                      style: TextStyle(fontWeight: FontWeight.w600),
                    ),
                    subtitle:
                    const Text('Toggle to show / hide notification'),
                    value: notificationEnabled,
                    onChanged: (value) async {
                      if (value) {
                        final status =
                        await Permission.notification.request();
                        if (status.isGranted) {
                          setState(() => notificationEnabled = true);
                          await NotificationService.showTestNotification();
                        } else {
                          setState(() => notificationEnabled = false);
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content:
                              Text('Notification permission denied'),
                            ),
                          );
                        }
                      } else {
                        setState(() => notificationEnabled = false);
                        await NotificationService.cancelTestNotification();
                      }
                    },
                    activeColor: Colors.blue,
                  ),
                ),
              ),

              // KPI cards
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Row(
                  children: [
                    kpiCard('Today', todayTotal(expenses), Colors.blue),
                    kpiCard('Month', monthTotal(expenses), Colors.green),
                    kpiCard('Total', overallTotal(expenses), Colors.purple),
                  ],
                ),
              ),

              const SizedBox(height: 12),

              // 📊 Bar Chart
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: CategoryBarChart(expenses: expenses),
              ),

              const SizedBox(height: 12),

              // Expense List
              Expanded(
                child: ListView.builder(
                  itemCount: expenses.length,
                  itemBuilder: (context, index) {
                    final e = expenses[index];

                    return Dismissible(
                      key: ValueKey(e.id),
                      direction: DismissDirection.endToStart,
                      background: Container(
                        alignment: Alignment.centerRight,
                        padding: const EdgeInsets.only(right: 20),
                        color: Colors.red,
                        child:
                        const Icon(Icons.delete, color: Colors.white),
                      ),
                      onDismissed: (_) async {
                        await ExpenseService.deleteExpense(e.id);
                        setState(() {
                          _expensesFuture =
                              ExpenseService.getExpenses();
                        });
                      },
                      child: ListTile(
                        onTap: () async {
                          final updated = await Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  EditExpenseScreen(expense: e),
                            ),
                          );
                          if (updated == true) {
                            setState(() {
                              _expensesFuture =
                                  ExpenseService.getExpenses();
                            });
                          }
                        },
                        leading: CircleAvatar(
                          backgroundColor:
                          getCategoryColor(e.category).withOpacity(0.15),
                          child: Icon(
                            getCategoryIcon(e.category),
                            color: getCategoryColor(e.category),
                          ),
                        ),
                        title: Text(e.title),
                        subtitle: Text(
                          '${e.category} • ${e.date.toLocal().toString().split(' ')[0]}',
                        ),
                        trailing: Text(
                          '₹${e.amount}',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            color: Colors.blue,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
