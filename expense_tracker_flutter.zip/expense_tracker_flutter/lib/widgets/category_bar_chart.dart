import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../models/expense.dart';

class CategoryBarChart extends StatelessWidget {
  final List<Expense> expenses;

  const CategoryBarChart({super.key, required this.expenses});

  @override
  Widget build(BuildContext context) {
    if (expenses.isEmpty) {
      return const Center(child: Text('No data'));
    }

    // ================= GROUP TOTALS BY CATEGORY =================
    final Map<String, double> categoryTotals = {};

    for (final e in expenses) {
      categoryTotals[e.category] =
          (categoryTotals[e.category] ?? 0) + e.amount;
    }

    final categories = categoryTotals.keys.toList();

    final barGroups = List.generate(categories.length, (index) {
      final value = categoryTotals[categories[index]]!;
      return BarChartGroupData(
        x: index,
        barRods: [
          BarChartRodData(
            toY: value,
            width: 18,
            borderRadius: BorderRadius.circular(6),
            color: Colors.blue,
          ),
        ],
      );
    });

    // ================= CHART =================
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Category-wise Spending',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 12),

        // 🔥 IMPORTANT: FIX OVERLAP BY CONTROLLING HEIGHT
        SizedBox(
          height: 220,
          child: BarChart(
            BarChartData(
              barGroups: barGroups,
              borderData: FlBorderData(show: false),
              gridData: FlGridData(show: true),

              // ================= TITLES =================
              titlesData: FlTitlesData(
                // ❌ NO TOP TITLES
                topTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),

                // ❌ NO RIGHT TITLES
                rightTitles: AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),

                // ✅ LEFT (Y-AXIS) — FIXED
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 42, // 🔥 SPACE FOR NUMBERS
                    interval: _getInterval(categoryTotals),
                    getTitlesWidget: (value, meta) {
                      return Text(
                        value.toInt().toString(),
                        style: const TextStyle(fontSize: 10),
                      );
                    },
                  ),
                ),

                // ✅ BOTTOM (CATEGORIES)
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (value, meta) {
                      if (value.toInt() >= categories.length) {
                        return const SizedBox.shrink();
                      }
                      return Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(
                          categories[value.toInt()],
                          style: const TextStyle(fontSize: 10),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ================= DYNAMIC INTERVAL =================
  double _getInterval(Map<String, double> totals) {
    final maxValue =
    totals.values.reduce((a, b) => a > b ? a : b);

    if (maxValue <= 500) return 100;
    if (maxValue <= 2000) return 500;
    if (maxValue <= 5000) return 1000;
    return 2000;
  }
}
